package com.aninterface.interactive.plateforme_thot_mobile

class Cours(var nom_cours: String, var niveau_cours:String, var Id_professeur:String, var desscription_cours:String, var photo:String)
{

}